import pygame
import random
import os
import sys

# Inicialização do Pygame
pygame.init()

# Inicializar o módulo de áudio do Pygame
pygame.mixer.init()

# Carregar e reproduzir a música
music_path = r"C:\Users\Nuno Lopes\Documents\05-Python\Project_1\Lá Sol Fá(s) - Canção de verão.mp3"
if os.path.exists(music_path):
    pygame.mixer.music.load(music_path)
    pygame.mixer.music.set_volume(0.8)  # Ajustar o volume (0.0 a 1.0)
    pygame.mixer.music.play(-1)  # Reproduzir em loop infinito
else:
    print(f"O ficheiro de música {music_path} não existe.")

# Definição das dimensões da janela
largura, altura = 300, 600
janela = pygame.display.set_mode((largura, altura))
pygame.display.set_caption("Evita os Brócolos!")

# Carregar a imagem de fundo
fundo_path = r"C:\Users\Nuno Lopes\Documents\05-Python\project_2\fundo.png"  # Substitua pelo caminho da sua imagem de fundo
if os.path.exists(fundo_path):
    fundo = pygame.image.load(fundo_path)
    fundo = pygame.transform.scale(fundo, (largura, altura))  # Redimensionar a imagem para caber na janela
else:
    print(f"O ficheiro de imagem de fundo {fundo_path} não existe.")
    fundo = None

# Cores
branco = (255, 255, 255)
amarelo = (255, 255, 0)
verde = (0, 255, 0)
preto = (0, 0, 0)
bordeau = (81, 12, 46)

# Função para ler a pontuação mais alta do ficheiro
def ler_pontuacao_mais_alta():
    try:
        with open("pontuacao_mais_alta.txt", "r") as ficheiro:
            return int(ficheiro.read())
    except FileNotFoundError:
        return 0

# Função para escrever a pontuação mais alta no ficheiro
def escrever_pontuacao_mais_alta(pontuacao):
    with open("pontuacao_mais_alta.txt", "w") as ficheiro:
        ficheiro.write(str(pontuacao))

# Classe do Pássaro
class Passaro:
    def __init__(self):
        self.x = largura // 2
        self.y = altura // 2
        self.raio = 20
        self.velocidade = 7

    def mover(self, direcao):
        if direcao == 'esquerda' and self.x - self.raio > 0:
            self.x -= self.velocidade
        if direcao == 'direita' and self.x + self.raio < largura:
            self.x += self.velocidade
        if direcao == 'cima' and self.y - self.raio > 0:
            self.y -= self.velocidade
        if direcao == 'baixo' and self.y + self.raio < altura:
            self.y += self.velocidade

    def desenhar(self, janela):
        pygame.draw.circle(janela, amarelo, (self.x, self.y), self.raio)

# Classe do Brócolo
class Brocolo:
    def __init__(self):
        self.x = random.randint(0, largura - 30)  # Ajustar para caber a imagem
        self.y = 0
        self.raio = 15
        self.velocidade = 18

    def mover(self):
        self.y += self.velocidade

    def desenhar(self, janela):
        pygame.draw.circle(janela, verde, (self.x + self.raio, self.y + self.raio), self.raio)  # Desenhar um círculo

    def fora_da_tela(self):
        return self.y > altura

# Função para exibir a mensagem de parabéns
def mostrar_mensagem_parabens():
    janela.fill(bordeau)
    fonte_media = pygame.font.SysFont(None, 30)
    texto_parabens1 = fonte_media.render("Nível 1 concluído!", True, preto)
    texto_parabens2 = fonte_media.render("Estás oficialmente convidado(a)", True, preto)
    texto_parabens3 = fonte_media.render("para o jantar do dia do trabalhador", True, preto)
    texto_parabens4 = fonte_media.render("no dia 30 de abril", True, preto)

    janela.blit(texto_parabens1, (largura // 2 - texto_parabens1.get_width() // 2, altura // 2 - 90))
    janela.blit(texto_parabens2, (largura // 2 - texto_parabens2.get_width() // 2, altura // 2 - 50))
    janela.blit(texto_parabens3, (largura // 2 - texto_parabens3.get_width() // 2, altura // 2 - 10))
    janela.blit(texto_parabens4, (largura // 2 - texto_parabens4.get_width() // 2, altura // 2 + 30))

    pygame.display.flip()
    pygame.time.wait(6000)  # Espera 6 segundos antes de fechar a mensagem

# Função para exibir a tela de Game Over com o botão "Jogar Novamente"
def mostrar_tela_game_over():
    janela.fill(bordeau)
    fonte_grande = pygame.font.SysFont(None, 48)
    fonte_media = pygame.font.SysFont(None, 30)
    texto_game_over = fonte_grande.render("Game Over", True, preto)
    texto_jogar_novamente = fonte_media.render("Clique para Jogar Novamente", True, preto)
    janela.blit(texto_game_over, (largura // 2 - texto_game_over.get_width() // 2, altura // 2 - 80))
    janela.blit(texto_jogar_novamente, (largura // 2 - texto_jogar_novamente.get_width() // 2, altura // 2))
    pygame.display.flip()

    esperando = True
    while esperando:
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if evento.type == pygame.MOUSEBUTTONDOWN:
                jogo()
                esperando = False

# Função principal do jogo
def jogo():
    relogio = pygame.time.Clock()
    passaro = Passaro()
    brocolos = []
    pontuacao = 0
    pontuacao_mais_alta = ler_pontuacao_mais_alta()
    fonte = pygame.font.SysFont(None, 36)
    tempo_ultimo_brocolo = 0
    intervalo_brocolo = 350  # 2 segundos

    rodando = True
    while rodando:
        tempo_atual = pygame.time.get_ticks()
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

        # Movimento do pássaro
        teclas = pygame.key.get_pressed()
        if teclas[pygame.K_LEFT]:
            passaro.mover('esquerda')
        if teclas[pygame.K_RIGHT]:
            passaro.mover('direita')
        if teclas[pygame.K_UP]:
            passaro.mover('cima')
        if teclas[pygame.K_DOWN]:
            passaro.mover('baixo')

        # Adicionar novos brócolos
        if tempo_atual - tempo_ultimo_brocolo > intervalo_brocolo:
            brocolos.append(Brocolo())
            tempo_ultimo_brocolo = tempo_atual

        # Movimento dos brócolos
        for brocolo in brocolos:
            brocolo.mover()
            if brocolo.fora_da_tela():
                brocolos.remove(brocolo)
                pontuacao += 1

        # Verificação de colisão
        for brocolo in brocolos:
            if ((passaro.x - (brocolo.x + brocolo.raio)) ** 2 + (passaro.y - (brocolo.y + brocolo.raio)) ** 2) ** 0.5 < (passaro.raio + brocolo.raio):
                mostrar_tela_game_over()
                rodando = False

        # Verificação da pontuação
        if pontuacao >= 150:
            mostrar_mensagem_parabens()
            rodando = False

        # Atualizar a pontuação mais alta
        if pontuacao > pontuacao_mais_alta:
            pontuacao_mais_alta = pontuacao
            escrever_pontuacao_mais_alta(pontuacao_mais_alta)

        # Desenho na janela
        if fundo:
            janela.blit(fundo, (0, 0))  # Desenhar a imagem de fundo
        else:
            janela.fill((120, 0, 120))  # Se a imagem de fundo não for carregada, usar a cor de fundo padrão

        passaro.desenhar(janela)
        for brocolo in brocolos:
            brocolo.desenhar(janela)

        # Desenho da pontuação
        texto_pontuacao = fonte.render(f'Score: {pontuacao}', True, preto)
        janela.blit(texto_pontuacao, (10, 10))

        # Desenho da pontuação mais alta
        texto_pontuacao_mais_alta = fonte.render(f'High Score: {pontuacao_mais_alta}', True, preto)
        janela.blit(texto_pontuacao_mais_alta, (10, 40))

        pygame.display.flip()
        relogio.tick(30)

# Executar o jogo
if __name__ == "__main__":
    jogo()
